var structscom__service__flags__t =
[
    [ "error", "structscom__service__flags__t.html#a11614f44ef4d939bdd984953346a7572", null ],
    [ "is_response", "structscom__service__flags__t.html#a66826220544fbc82f28118774115d1e8", null ],
    [ "reserved7to2", "structscom__service__flags__t.html#a373281cdba3ede51ccb55b97c2ea68b2", null ]
];