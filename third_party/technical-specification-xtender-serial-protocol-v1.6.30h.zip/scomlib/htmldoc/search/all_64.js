var searchData=
[
  ['data_5flength',['data_length',['../structscom__frame__t.html#ac710ca74549e34346fcf7c3a81c63ea3',1,'scom_frame_t']]],
  ['dst_5faddr',['dst_addr',['../structscom__frame__t.html#ad3367f6b5057b9c73b012338e5a437ae',1,'scom_frame_t']]]
];
