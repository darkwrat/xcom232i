var searchData=
[
  ['clear_5fserial_5fport',['clear_serial_port',['../usage__examples_8c.html#aea74c784a0fc1ee095cd8192de4f129e',1,'usage_examples.c']]],
  ['close_5fserial_5fport',['close_serial_port',['../usage__examples_8c.html#a1e9f7c594bc96d644191561ca07ee8ac',1,'usage_examples.c']]]
];
