var searchData=
[
  ['last_5ferror',['last_error',['../structscom__frame__t.html#a51fac12cbc5df14ceabf31d2089ac42b',1,'scom_frame_t']]]
];
