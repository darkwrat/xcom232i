var searchData=
[
  ['scom_5fframe_5fheader_5fsize',['SCOM_FRAME_HEADER_SIZE',['../scom__data__link_8h.html#a9310d14c7bbab38765915f97c40ed642',1,'scom_data_link.h']]],
  ['scom_5fmax',['SCOM_MAX',['../scom__data__link_8h.html#a793e36f7c043f0a723a1550f9aed24e1',1,'scom_data_link.h']]],
  ['scom_5fmin',['SCOM_MIN',['../scom__data__link_8h.html#aa8faa8715792e122255266119e4fde52',1,'scom_data_link.h']]],
  ['scom_5fnbr_5felements',['SCOM_NBR_ELEMENTS',['../scom__data__link_8h.html#a01d712a18a766d544ac363490c276ebe',1,'scom_data_link.h']]]
];
