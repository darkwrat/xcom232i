var searchData=
[
  ['frame',['frame',['../structscom__property__t.html#ae39168d9d6ad0d6aa54766a86e654019',1,'scom_property_t']]],
  ['frame_5fflags',['frame_flags',['../structscom__frame__t.html#aa4afee222b85532c78d0c2ea895ee3d2',1,'scom_frame_t']]]
];
