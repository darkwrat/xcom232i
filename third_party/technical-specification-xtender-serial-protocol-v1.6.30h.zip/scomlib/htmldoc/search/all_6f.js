var searchData=
[
  ['object_5fid',['object_id',['../structscom__property__t.html#a2d480a03830d09c2779dd04724669daf',1,'scom_property_t']]],
  ['object_5ftype',['object_type',['../structscom__property__t.html#a6b826133a7488c8bd992236825a56729',1,'scom_property_t']]]
];
