var searchData=
[
  ['read_5fserial_5fport',['read_serial_port',['../usage__examples_8c.html#a4a5c7bef6e0753513b775e25be7c99a6',1,'usage_examples.c']]],
  ['read_5fxt1_5fubat',['read_xt1_uBat',['../usage__examples_8c.html#ae5dde42bb838a5d9be5b025ae2a22245',1,'usage_examples.c']]]
];
