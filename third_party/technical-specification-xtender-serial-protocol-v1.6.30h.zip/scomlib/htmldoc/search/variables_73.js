var searchData=
[
  ['service_5fflags',['service_flags',['../structscom__frame__t.html#a1840660e9a78c3a971f980db98811697',1,'scom_frame_t']]],
  ['service_5fid',['service_id',['../structscom__frame__t.html#accf76f7627cad7f4687f39e1f877bf1a',1,'scom_frame_t']]],
  ['src_5faddr',['src_addr',['../structscom__frame__t.html#a6a462ff6ecd832025b4f8934f226d5b5',1,'scom_frame_t']]]
];
