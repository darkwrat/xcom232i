var searchData=
[
  ['value_5fbuffer',['value_buffer',['../structscom__property__t.html#a0758123490ef03a7ea0553c638f7efbe',1,'scom_property_t']]],
  ['value_5fbuffer_5fsize',['value_buffer_size',['../structscom__property__t.html#af1928e793638ae5a66c8077414ea1779',1,'scom_property_t']]],
  ['value_5flength',['value_length',['../structscom__property__t.html#a0d12dccc31550b633c0136967c0c069f',1,'scom_property_t']]]
];
