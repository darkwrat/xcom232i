var searchData=
[
  ['buffer',['buffer',['../structscom__frame__t.html#aff2566f4c366b48d73479bef43ee4d2e',1,'scom_frame_t']]],
  ['buffer_5fsize',['buffer_size',['../structscom__frame__t.html#a799a743b3abd553a37fc01ad3097df08',1,'scom_frame_t']]]
];
