var scom__property_8h =
[
    [ "scom_property_t", "structscom__property__t.html", "structscom__property__t" ],
    [ "scom_object_type_t", "scom__property_8h.html#a9e23640ef6437369ecaba755ade9d355", [
      [ "SCOM_USER_INFO_OBJECT_TYPE", "scom__property_8h.html#a9e23640ef6437369ecaba755ade9d355abb8dcbaec5682d99c8ff688ef7655800", null ],
      [ "SCOM_PARAMETER_OBJECT_TYPE", "scom__property_8h.html#a9e23640ef6437369ecaba755ade9d355a7dfc4418152bdb5c7b7662caba41c64a", null ]
    ] ],
    [ "scom_decode_read_property", "scom__property_8h.html#a9539f7006cd2552b99c0abeca4d1cebe", null ],
    [ "scom_decode_write_property", "scom__property_8h.html#ad3678fdda9be4efad296e25d755dac59", null ],
    [ "scom_encode_read_property", "scom__property_8h.html#a7bbba0191ab9937d0ea6d2e59c569f69", null ],
    [ "scom_encode_write_property", "scom__property_8h.html#afa0597ef2fa76dd9e7c5b61620c7bddf", null ],
    [ "scom_initialize_property", "scom__property_8h.html#a78a650c5533c72318a517ec7857b4550", null ]
];