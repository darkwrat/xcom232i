var usage__examples_8c =
[
    [ "clear_serial_port", "usage__examples_8c.html#aea74c784a0fc1ee095cd8192de4f129e", null ],
    [ "close_serial_port", "usage__examples_8c.html#a1e9f7c594bc96d644191561ca07ee8ac", null ],
    [ "exchange_frame", "usage__examples_8c.html#a3aa974c8ff5474f1d031be227685c2f6", null ],
    [ "initialize_serial_port", "usage__examples_8c.html#ad5aa787381b1ef9aebdb6d954578e576", null ],
    [ "main", "usage__examples_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "read_serial_port", "usage__examples_8c.html#a4a5c7bef6e0753513b775e25be7c99a6", null ],
    [ "read_xt1_uBat", "usage__examples_8c.html#ae5dde42bb838a5d9be5b025ae2a22245", null ],
    [ "write_serial_port", "usage__examples_8c.html#a559ec32724f5c5f4b78f94c7ba268b23", null ]
];