var structscom__frame__t =
[
    [ "buffer", "structscom__frame__t.html#aff2566f4c366b48d73479bef43ee4d2e", null ],
    [ "buffer_size", "structscom__frame__t.html#a799a743b3abd553a37fc01ad3097df08", null ],
    [ "data_length", "structscom__frame__t.html#ac710ca74549e34346fcf7c3a81c63ea3", null ],
    [ "dst_addr", "structscom__frame__t.html#ad3367f6b5057b9c73b012338e5a437ae", null ],
    [ "frame_flags", "structscom__frame__t.html#aa4afee222b85532c78d0c2ea895ee3d2", null ],
    [ "last_error", "structscom__frame__t.html#a51fac12cbc5df14ceabf31d2089ac42b", null ],
    [ "service_flags", "structscom__frame__t.html#a1840660e9a78c3a971f980db98811697", null ],
    [ "service_id", "structscom__frame__t.html#accf76f7627cad7f4687f39e1f877bf1a", null ],
    [ "src_addr", "structscom__frame__t.html#a6a462ff6ecd832025b4f8934f226d5b5", null ]
];