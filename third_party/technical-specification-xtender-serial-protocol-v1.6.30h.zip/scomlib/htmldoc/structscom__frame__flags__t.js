var structscom__frame__flags__t =
[
    [ "is_message_pending", "structscom__frame__flags__t.html#ac7d7a0c8c5e0898158e7ad2ebcbbfa21", null ],
    [ "is_new_datalogger_file_present", "structscom__frame__flags__t.html#a1931e06ed53d8ed1a02420f8ccefcaca", null ],
    [ "is_sd_card_full", "structscom__frame__flags__t.html#af5a6dba8989c098aba9464cc7ba4b4e1", null ],
    [ "is_sd_card_present", "structscom__frame__flags__t.html#a951d01491c212a96a9e886ff703f85e7", null ],
    [ "reserved7to5", "structscom__frame__flags__t.html#a5b825bfdae9e0060b62b0794b21061f8", null ],
    [ "was_rcc_reseted", "structscom__frame__flags__t.html#a6a7df5650f6ea186ba17a50c9998d2b3", null ]
];