var structscom__property__t =
[
    [ "frame", "structscom__property__t.html#ae39168d9d6ad0d6aa54766a86e654019", null ],
    [ "object_id", "structscom__property__t.html#a2d480a03830d09c2779dd04724669daf", null ],
    [ "object_type", "structscom__property__t.html#a6b826133a7488c8bd992236825a56729", null ],
    [ "property_id", "structscom__property__t.html#ad39bfe7de446e4fc386ed7c3645acbcd", null ],
    [ "value_buffer", "structscom__property__t.html#a0758123490ef03a7ea0553c638f7efbe", null ],
    [ "value_buffer_size", "structscom__property__t.html#af1928e793638ae5a66c8077414ea1779", null ],
    [ "value_length", "structscom__property__t.html#a0d12dccc31550b633c0136967c0c069f", null ]
];