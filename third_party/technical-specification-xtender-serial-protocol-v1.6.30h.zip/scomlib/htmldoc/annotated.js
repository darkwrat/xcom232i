var annotated =
[
    [ "scom_frame_flags_t", "structscom__frame__flags__t.html", "structscom__frame__flags__t" ],
    [ "scom_frame_t", "structscom__frame__t.html", "structscom__frame__t" ],
    [ "scom_property_t", "structscom__property__t.html", "structscom__property__t" ],
    [ "scom_service_flags_t", "structscom__service__flags__t.html", "structscom__service__flags__t" ]
];